%% POPCORN METAPHOR: Voronoi Analysis of Spatial Distributions
% This script demonstrates the difference between hyperuniform (dry) and 
% clustered (oiled) point distributions through Voronoi tessellation analysis.
%
% Author: Maayan Keynan
% Date: January 2026
% Associated Paper: "The Popcorn Metaphor: A Framework for Understanding 
%                   Order, Entropy, and Phase Transitions in Granular Systems"
%
% USAGE:
%   Run this script in MATLAB. It will generate:
%   1. Two point distributions (hyperuniform-like and clustered)
%   2. Voronoi tessellations for each
%   3. Cell area statistics and histograms
%   4. Comparison figure
%   5. CSV file with summary statistics
%
% REQUIREMENTS:
%   - MATLAB R2016b or later
%   - No additional toolboxes required

%% Clear workspace
clear; close all; clc;

%% Parameters
N_points = 36;          % Number of points (6x6 grid equivalent)
domain = [0 1 0 1];     % Unit square domain [xmin xmax ymin ymax]
rng(42);                % Set random seed for reproducibility

%% PART 1: Generate Point Distributions

% --- Hyperuniform-like distribution (quasi-regular grid with jitter) ---
% This simulates dry kernels that self-organize into uniform spacing

grid_size = sqrt(N_points);  % 6x6 grid
jitter_magnitude = 0.02;     % Small jitter to avoid perfect grid

% Create base grid
[X_grid, Y_grid] = meshgrid(linspace(0.08, 0.92, grid_size), ...
                            linspace(0.08, 0.92, grid_size));

% Add small random jitter
X_hyper = X_grid(:) + jitter_magnitude * (rand(N_points, 1) - 0.5);
Y_hyper = Y_grid(:) + jitter_magnitude * (rand(N_points, 1) - 0.5);

% Ensure points stay within domain
X_hyper = max(0.01, min(0.99, X_hyper));
Y_hyper = max(0.01, min(0.99, Y_hyper));

points_hyperuniform = [X_hyper, Y_hyper];

% --- Clustered distribution (simulating oiled kernels) ---
% Create 2-3 clusters with voids between them

% Cluster 1: top-left region
n1 = 12;
cluster1_x = 0.2 + 0.15 * randn(n1, 1);
cluster1_y = 0.75 + 0.12 * randn(n1, 1);

% Cluster 2: bottom-right region  
n2 = 14;
cluster2_x = 0.75 + 0.12 * randn(n2, 1);
cluster2_y = 0.25 + 0.15 * randn(n2, 1);

% Cluster 3: center (sparse)
n3 = N_points - n1 - n2;
cluster3_x = 0.5 + 0.3 * randn(n3, 1);
cluster3_y = 0.5 + 0.25 * randn(n3, 1);

% Combine clusters
X_clust = [cluster1_x; cluster2_x; cluster3_x];
Y_clust = [cluster1_y; cluster2_y; cluster3_y];

% Ensure points stay within domain
X_clust = max(0.01, min(0.99, X_clust));
Y_clust = max(0.01, min(0.99, Y_clust));

points_clustered = [X_clust, Y_clust];

%% PART 2: Compute Voronoi Tessellations and Cell Areas

% Function to compute bounded Voronoi cell areas
% (Using polygon clipping to unit square)

[areas_hyper, vertices_hyper, cells_hyper] = computeBoundedVoronoiAreas(points_hyperuniform, domain);
[areas_clust, vertices_clust, cells_clust] = computeBoundedVoronoiAreas(points_clustered, domain);

%% PART 3: Statistical Analysis

% --- Hyperuniform distribution statistics ---
mean_area_hyper = mean(areas_hyper);
std_area_hyper = std(areas_hyper);
var_area_hyper = var(areas_hyper);
cv_hyper = std_area_hyper / mean_area_hyper;  % Coefficient of variation

% Shannon entropy of area distribution
p_hyper = areas_hyper / sum(areas_hyper);
entropy_hyper = -sum(p_hyper .* log2(p_hyper + eps));

% --- Clustered distribution statistics ---
mean_area_clust = mean(areas_clust);
std_area_clust = std(areas_clust);
var_area_clust = var(areas_clust);
cv_clust = std_area_clust / mean_area_clust;

% Shannon entropy of area distribution
p_clust = areas_clust / sum(areas_clust);
entropy_clust = -sum(p_clust .* log2(p_clust + eps));

%% PART 4: Display Results

fprintf('\n========================================\n');
fprintf('POPCORN METAPHOR: Voronoi Analysis Results\n');
fprintf('========================================\n\n');

fprintf('HYPERUNIFORM (Dry Kernels):\n');
fprintf('  Number of cells: %d\n', length(areas_hyper));
fprintf('  Mean cell area: %.4f\n', mean_area_hyper);
fprintf('  Std deviation: %.4f\n', std_area_hyper);
fprintf('  Variance: %.6f\n', var_area_hyper);
fprintf('  Coefficient of Variation: %.4f\n', cv_hyper);
fprintf('  Shannon Entropy: %.4f bits\n\n', entropy_hyper);

fprintf('CLUSTERED (Oiled Kernels):\n');
fprintf('  Number of cells: %d\n', length(areas_clust));
fprintf('  Mean cell area: %.4f\n', mean_area_clust);
fprintf('  Std deviation: %.4f\n', std_area_clust);
fprintf('  Variance: %.6f\n', var_area_clust);
fprintf('  Coefficient of Variation: %.4f\n', cv_clust);
fprintf('  Shannon Entropy: %.4f bits\n\n', entropy_clust);

fprintf('COMPARISON:\n');
fprintf('  Variance ratio (clustered/hyperuniform): %.2f\n', var_area_clust/var_area_hyper);
fprintf('  CV ratio (clustered/hyperuniform): %.2f\n', cv_clust/cv_hyper);
fprintf('  Entropy difference: %.4f bits\n', entropy_clust - entropy_hyper);
fprintf('\n========================================\n');

%% PART 5: Visualization

fig = figure('Position', [100, 100, 1200, 500], 'Color', 'white');

% --- Panel A: Hyperuniform Voronoi ---
subplot(1, 3, 1);
hold on;

% Plot Voronoi diagram
voronoi(points_hyperuniform(:,1), points_hyperuniform(:,2), 'b-');

% Plot points
plot(points_hyperuniform(:,1), points_hyperuniform(:,2), 'bo', ...
     'MarkerFaceColor', [0.1, 0.2, 0.6], 'MarkerSize', 8);

% Formatting
xlim([0 1]); ylim([0 1]);
axis square;
title({'(A) Hyperuniform Distribution', '(Dry Kernels)'}, 'FontSize', 12, 'FontWeight', 'bold');
xlabel('x'); ylabel('y');
box on;
hold off;

% --- Panel B: Clustered Voronoi ---
subplot(1, 3, 2);
hold on;

% Plot Voronoi diagram
voronoi(points_clustered(:,1), points_clustered(:,2), 'r-');

% Plot points
plot(points_clustered(:,1), points_clustered(:,2), 'ro', ...
     'MarkerFaceColor', [0.7, 0.1, 0.1], 'MarkerSize', 8);

% Formatting
xlim([0 1]); ylim([0 1]);
axis square;
title({'(B) Clustered Distribution', '(Oiled Kernels)'}, 'FontSize', 12, 'FontWeight', 'bold');
xlabel('x'); ylabel('y');
box on;
hold off;

% --- Panel C: Area Distribution Comparison ---
subplot(1, 3, 3);
hold on;

% Histogram bins
edges = linspace(0, max([areas_hyper; areas_clust]) * 1.1, 20);

% Plot histograms
histogram(areas_hyper, edges, 'FaceColor', [0.3, 0.5, 0.9], 'FaceAlpha', 0.7, ...
          'EdgeColor', 'b', 'DisplayName', 'Hyperuniform');
histogram(areas_clust, edges, 'FaceColor', [0.9, 0.4, 0.4], 'FaceAlpha', 0.7, ...
          'EdgeColor', 'r', 'DisplayName', 'Clustered');

% Formatting
xlabel('Cell Area', 'FontSize', 11);
ylabel('Frequency', 'FontSize', 11);
title({'(C) Cell Area Distribution', ''}, 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northeast');

% Add statistics annotation
text_x = max(edges) * 0.55;
text_y = max(ylim) * 0.85;
text(text_x, text_y, sprintf('Hyperuniform:\n  CV = %.3f\n  H = %.2f bits', cv_hyper, entropy_hyper), ...
     'FontSize', 9, 'Color', 'b', 'VerticalAlignment', 'top');
text(text_x, text_y * 0.55, sprintf('Clustered:\n  CV = %.3f\n  H = %.2f bits', cv_clust, entropy_clust), ...
     'FontSize', 9, 'Color', 'r', 'VerticalAlignment', 'top');

box on;
hold off;

%% PART 6: Export Results

% Save figures in multiple formats
saveas(fig, 'Popcorn_Voronoi_Analysis.fig');        % MATLAB format (editable)
saveas(fig, 'Popcorn_Voronoi_Analysis.png');        % Standard PNG
print(fig, 'Popcorn_Voronoi_Analysis_HighRes', '-dpng', '-r300');  % 300 DPI for publication

fprintf('\nFigures saved:\n');
fprintf('  - Popcorn_Voronoi_Analysis.fig (editable MATLAB format)\n');
fprintf('  - Popcorn_Voronoi_Analysis.png (standard resolution)\n');
fprintf('  - Popcorn_Voronoi_Analysis_HighRes.png (300 DPI publication quality)\n');

% Export statistics to CSV
Distribution = {'Hyperuniform'; 'Clustered'};
N_cells = [length(areas_hyper); length(areas_clust)];
Mean_Area = [mean_area_hyper; mean_area_clust];
Std_Dev = [std_area_hyper; std_area_clust];
Variance = [var_area_hyper; var_area_clust];
CV = [cv_hyper; cv_clust];
Shannon_Entropy_bits = [entropy_hyper; entropy_clust];

stats_table = table(Distribution, N_cells, Mean_Area, Std_Dev, Variance, CV, Shannon_Entropy_bits);

writetable(stats_table, 'Popcorn_Voronoi_Statistics.csv');
fprintf('  - Popcorn_Voronoi_Statistics.csv (summary statistics)\n\n');

%% HELPER FUNCTION: Compute Bounded Voronoi Cell Areas

function [areas, V, C] = computeBoundedVoronoiAreas(points, domain)
    % Computes Voronoi cell areas bounded by a rectangular domain
    %
    % INPUTS:
    %   points: Nx2 array of point coordinates
    %   domain: [xmin xmax ymin ymax] bounding rectangle
    %
    % OUTPUTS:
    %   areas: Nx1 vector of cell areas
    %   V: Voronoi vertices
    %   C: Voronoi cell vertex indices
    
    xmin = domain(1); xmax = domain(2);
    ymin = domain(3); ymax = domain(4);
    
    % Add boundary points to ensure bounded cells
    % (This is a common technique for bounded Voronoi)
    boundary_margin = 2;
    boundary_points = [
        xmin - boundary_margin, ymin - boundary_margin;
        xmax + boundary_margin, ymin - boundary_margin;
        xmin - boundary_margin, ymax + boundary_margin;
        xmax + boundary_margin, ymax + boundary_margin;
        (xmin + xmax)/2, ymin - boundary_margin;
        (xmin + xmax)/2, ymax + boundary_margin;
        xmin - boundary_margin, (ymin + ymax)/2;
        xmax + boundary_margin, (ymin + ymax)/2;
    ];
    
    all_points = [points; boundary_points];
    
    % Compute Voronoi
    [V, C] = voronoin(all_points);
    
    % Compute areas for original points only
    n_original = size(points, 1);
    areas = zeros(n_original, 1);
    
    for i = 1:n_original
        cell_vertices = C{i};
        
        % Skip cells with infinite vertices
        if any(cell_vertices == 1)
            % Approximate with a large value or use clipping
            areas(i) = NaN;
            continue;
        end
        
        % Get vertex coordinates
        vx = V(cell_vertices, 1);
        vy = V(cell_vertices, 2);
        
        % Clip to domain using simple polygon intersection
        [vx_clipped, vy_clipped] = clipPolygonToRect(vx, vy, xmin, xmax, ymin, ymax);
        
        if length(vx_clipped) >= 3
            % Compute area using shoelace formula
            areas(i) = polyarea(vx_clipped, vy_clipped);
        else
            areas(i) = NaN;
        end
    end
    
    % Remove NaN values (boundary cells that couldn't be computed)
    areas = areas(~isnan(areas));
end

function [xc, yc] = clipPolygonToRect(x, y, xmin, xmax, ymin, ymax)
    % Simple polygon clipping to rectangle using Sutherland-Hodgman algorithm
    % (Simplified version for convex polygons)
    
    % Clip against each edge of the rectangle
    [x, y] = clipAgainstEdge(x, y, xmin, 'left');
    [x, y] = clipAgainstEdge(x, y, xmax, 'right');
    [x, y] = clipAgainstEdge(x, y, ymin, 'bottom');
    [x, y] = clipAgainstEdge(x, y, ymax, 'top');
    
    xc = x;
    yc = y;
end

function [xout, yout] = clipAgainstEdge(x, y, edge_val, edge_type)
    % Clip polygon against one edge
    
    if isempty(x)
        xout = []; yout = [];
        return;
    end
    
    n = length(x);
    xout = [];
    yout = [];
    
    for i = 1:n
        j = mod(i, n) + 1;  % Next vertex (wraps around)
        
        % Current and next vertex
        x1 = x(i); y1 = y(i);
        x2 = x(j); y2 = y(j);
        
        % Check if vertices are inside
        inside1 = isInsideEdge(x1, y1, edge_val, edge_type);
        inside2 = isInsideEdge(x2, y2, edge_val, edge_type);
        
        if inside1 && inside2
            % Both inside: add second vertex
            xout = [xout; x2];
            yout = [yout; y2];
        elseif inside1 && ~inside2
            % Going out: add intersection
            [xi, yi] = intersectEdge(x1, y1, x2, y2, edge_val, edge_type);
            xout = [xout; xi];
            yout = [yout; yi];
        elseif ~inside1 && inside2
            % Coming in: add intersection and second vertex
            [xi, yi] = intersectEdge(x1, y1, x2, y2, edge_val, edge_type);
            xout = [xout; xi; x2];
            yout = [yout; yi; y2];
        end
        % Both outside: add nothing
    end
end

function inside = isInsideEdge(x, y, edge_val, edge_type)
    switch edge_type
        case 'left'
            inside = x >= edge_val;
        case 'right'
            inside = x <= edge_val;
        case 'bottom'
            inside = y >= edge_val;
        case 'top'
            inside = y <= edge_val;
    end
end

function [xi, yi] = intersectEdge(x1, y1, x2, y2, edge_val, edge_type)
    switch edge_type
        case {'left', 'right'}
            xi = edge_val;
            t = (edge_val - x1) / (x2 - x1 + eps);
            yi = y1 + t * (y2 - y1);
        case {'bottom', 'top'}
            yi = edge_val;
            t = (edge_val - y1) / (y2 - y1 + eps);
            xi = x1 + t * (x2 - x1);
    end
end